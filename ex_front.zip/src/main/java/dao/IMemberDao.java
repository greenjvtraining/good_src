package dao;

import java.util.List;

import dto.MemberDto;

public interface IMemberDao {
	public List<MemberDto> getMemberList();
	public MemberDto getMember(String id);
	public boolean loginCheck(String id, String pw);
}
