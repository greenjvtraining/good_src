package service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import dao.IMemberDao;
import dto.MemberDto;
import util.MybatisSqlSessionFactory;

public class MemberService {
	
	private SqlSessionFactory sqlSessionFactory 
	= MybatisSqlSessionFactory.getSqlSessionFactory();

	private SqlSession session = sqlSessionFactory.openSession(true);
	private IMemberDao memberDao = session.getMapper(IMemberDao.class);
	
	public List<MemberDto> getMemberList(){
		return memberDao.getMemberList();
	}
	
	public MemberDto getMember(String id) {
		return memberDao.getMember(id);
	}
	
	public boolean loginCheck(String id, String pw) {
		return memberDao.loginCheck(id, pw);
	}
}
