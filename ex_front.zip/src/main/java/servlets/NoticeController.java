package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dto.NoticeDto;
import dto.ReplyDto;
import service.NoticeService;
import service.ReplyService;

@WebServlet("*.do")
public class NoticeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	NoticeService noticeService = new NoticeService();
	ReplyService replyService = new ReplyService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String view = null;
		
		String uri = request.getRequestURI();
		System.out.println("uri : " + uri);
		
		String contextPath = request.getContextPath();
		System.out.println("contextPath : " + contextPath);
		
		String com = uri.substring(contextPath.length());
		System.out.println("com : " + com);
		
		if(com.equals("/list.do")) {
			System.out.println("list.do.........");
			List<NoticeDto> noticeList = noticeService.getNoticeList();
			
			request.setAttribute("noticeList", noticeList);
			view = "list.jsp";
			
		}else if(com.equals("/regist_form.do")) {
			System.out.println("regist_form.do.........");
			
			view = "redirect:regist_form.jsp";
			
		}else if(com.equals("/login_form.do")) {
			System.out.println("login_form.do.........");
			
			view = "redirect:login_form.jsp";
			
		}else if(com.equals("/regist.do")) {
			System.out.println("regist.do.........");
			
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			String writer = request.getParameter("writer");
			
			NoticeDto notice = new NoticeDto(title, content, writer);
			
			noticeService.registNotice(notice);
			
			view = "redirect:list.do";
			
		}else if(com.equals("/login.do")) {
			System.out.println("login.do.........");
			
			view = "redirect:success.jsp";
			
		}else if(com.equals("/detail_notice.do")) {
			System.out.println("detail_notice.do.........");
			
			
			String nno_ = request.getParameter("nno");
			int nno = Integer.parseInt(nno_);
			
			List<ReplyDto> replyList = replyService.getReplyList(nno);
			NoticeDto noticeDto = noticeService.getNotice(nno);
			
			request.setAttribute("notice", noticeDto);
			request.setAttribute("replyList", replyList);
			
			view = "detail_notice.jsp";
			
		}else if(com.equals("/reg_reply.do")) {
			System.out.println("댓들 등록....");
			String snno = request.getParameter("nno");
			int nno = Integer.parseInt(snno);
			String comment = request.getParameter("comment");
			String writer = request.getParameter("writer");
			
			ReplyDto reply = new ReplyDto(nno, comment, writer, null);
			System.out.println("reply: " + reply);
			replyService.saveReply(reply);
			
			List<ReplyDto> replyList = replyService.getReplyList(nno);
			
			Gson gson = new Gson();
			String json_str = gson.toJson(replyList);
			System.out.println("replyList : " + json_str);
			
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json_str);
			
		}else if(com.equals("/del_reply.do")) {
			System.out.println("del_reply.do.....");
			String rno_ = request.getParameter("rno");
			int rno = Integer.parseInt(rno_);
			String nno_ = request.getParameter("nno");
			int nno = Integer.parseInt(nno_);
			
			replyService.deleteReply(rno);
			response.setCharacterEncoding("utf-8");
			
			List<ReplyDto> replyList = replyService.getReplyList(nno);
			
			Gson gson = new Gson();
			String json_str = gson.toJson(replyList);
			System.out.println("replyList : " + json_str);
			
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json_str);
		}
		
		//view 전송 방법 설정하기
		if(view != null) {
			if(view.startsWith("redirect:")) {
				response.sendRedirect(view.substring(9));
				
			}else {
				request.getRequestDispatcher(view).forward(request, response);
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
